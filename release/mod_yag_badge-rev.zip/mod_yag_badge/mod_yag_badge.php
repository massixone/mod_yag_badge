<?php
/*------------------------------------------------------------------------
# mod_yet_another_google_plus_badge - Yet Another Google Plus Badges
# ------------------------------------------------------------------------
# @author - Massimo di Primio Independent ICT Consultant
# copyright Copyright (C) 2015 diprimio.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.diprimio.com
# Technical Support:  Forum - http://www.diprimio.com/support.html
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die;
require JModuleHelper::getLayoutPath('mod_yag_badge', $params->get('layout'));
